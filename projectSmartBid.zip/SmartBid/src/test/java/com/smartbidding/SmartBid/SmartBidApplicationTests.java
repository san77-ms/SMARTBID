package com.smartbidding.SmartBid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartBidApplicationTests {

	@Test
	void contextLoads() {
	}

}
