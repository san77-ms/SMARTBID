package com.smartbidding.SmartBid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartBidApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartBidApplication.class, args);
	}

}
