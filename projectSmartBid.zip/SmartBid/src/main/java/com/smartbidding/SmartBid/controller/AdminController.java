package com.smartbidding.SmartBid.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartbidding.SmartBid.exceptions.ResourceNotFoundException;
import com.smartbidding.SmartBid.model.Product;
import com.smartbidding.SmartBid.model.SellerManage;
import com.smartbidding.SmartBid.repository.ProductRepo;
import com.smartbidding.SmartBid.repository.SellerRepo;

@CrossOrigin(origins = "http://localhost:3000")

@RestController
@RequestMapping("/api/v1")
public class AdminController {
	@Autowired
    ProductRepo prepo;
	@Autowired
	SellerRepo sepo;
	@PostMapping("/product")
	public Product createProduct(@RequestBody Product product) {
		return prepo.save(product);
	}
	@GetMapping("/product")
	public List<Product> getAllproducts() {
		return prepo.findAll();
	}

	@GetMapping("/product/{id}")
	public ResponseEntity<Product> getproductById(@PathVariable(value = "id") Long productId)
			throws ResourceNotFoundException {
		Product product = prepo.findById(productId)
				.orElseThrow(() -> new ResourceNotFoundException("product not found for this id :: " + productId));
		return ResponseEntity.ok().body(product);
	}

	@PutMapping("/product/{id}")
	public ResponseEntity<Product> updateproduct(@PathVariable(value = "id") Long productId,
			 @RequestBody Product productDetails) throws ResourceNotFoundException {
		Product product = prepo.findById(productId)
				.orElseThrow(() -> new ResourceNotFoundException("product not found for this id :: " + productId));
        product.setBaseprice(productDetails.getBaseprice());
        product.setDescription(productDetails.getDescription());
        product.setName(productDetails.getName());
        
		final Product updatedproduct = prepo.save(product);
		return ResponseEntity.ok(updatedproduct);
	}

	@DeleteMapping("/product/{id}")
	public Map<String, Boolean> deleteproduct(@PathVariable(value = "id") Long productId)
			throws ResourceNotFoundException {
		Product product = prepo.findById(productId)
				.orElseThrow(() -> new ResourceNotFoundException("product not found for this id :: " + productId));

		prepo.delete(product);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}	
	
	//SellerDetails
	
	@GetMapping("/sellermanage")
	public List<SellerManage> getSellers() {
		return sepo.findAll();
	}
	
	@PostMapping("/sellermanage")
	public SellerManage createSeller(@RequestBody SellerManage sellermanage) {
		return sepo.save(sellermanage);}
	
	@PutMapping("/sellermanage/{id}")
	public ResponseEntity<SellerManage> updateproduct(@PathVariable(value = "id") Long sellerId,
			 @RequestBody SellerManage sellerDetails) throws ResourceNotFoundException {
		SellerManage seller = sepo.findById(sellerId)
				.orElseThrow(() -> new ResourceNotFoundException("seller not found for this id :: " + sellerId));
		seller.setRating(sellerDetails.getRating());
		seller.setEmail(sellerDetails.getEmail());
		seller.setName(sellerDetails.getName());
        
		final SellerManage updatedseller = sepo.save(seller);
		return ResponseEntity.ok(updatedseller);
		
}
	@DeleteMapping("/sellermanage/{id}")
	public Map<String, Boolean> deleteseller(@PathVariable(value = "id") Long sellerId)
			throws ResourceNotFoundException {
		SellerManage seller = sepo.findById(sellerId)
				.orElseThrow(() -> new ResourceNotFoundException("seller not found for this id :: " + sellerId));

		sepo.delete(seller);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}
}
