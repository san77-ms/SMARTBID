package com.smartbidding.SmartBid.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.smartbidding.SmartBid.model.Product;
import com.smartbidding.SmartBid.model.SellerManage;
@Repository
public interface SellerRepo extends JpaRepository<SellerManage, Long> {

}
